"""
A Radar Simulator for Python

RadarSimPy is a powerful and versatile Python-based Radar Simulator that models
radar transceivers and simulates baseband data from point targets and 3D models.
Its signal processing tools offer range/Doppler processing, direction of arrival
estimation, and beamforming using various cutting-edge techniques, and you can
even characterize radar detection using Swerling's models. Whether you're a beginner
or an advanced user, RadarSimPy is the perfect tool for anyone looking to develop
new radar technologies or expand their knowledge of radar systems.

---

- Copyright (C) 2018 - PRESENT  radarsimx.com
- E-mail: info@radarsimx.com
- Website: https://radarsimx.com

::

    ██████╗  █████╗ ██████╗  █████╗ ██████╗ ███████╗██╗███╗   ███╗██╗  ██╗
    ██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔════╝██║████╗ ████║╚██╗██╔╝
    ██████╔╝███████║██║  ██║███████║██████╔╝███████╗██║██╔████╔██║ ╚███╔╝ 
    ██╔══██╗██╔══██║██║  ██║██╔══██║██╔══██╗╚════██║██║██║╚██╔╝██║ ██╔██╗ 
    ██║  ██║██║  ██║██████╔╝██║  ██║██║  ██║███████║██║██║ ╚═╝ ██║██╔╝ ██╗
    ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝╚═╝     ╚═╝╚═╝  ╚═╝

"""

from .radar import Radar
from .transmitter import Transmitter
from .receiver import Receiver

__version__ = "12.5.0"
